package com.salesianostriana.dam.ud8e09listadosbasicos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ud8E09ListadosBasicosApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ud8E09ListadosBasicosApplication.class, args);
	}

}
