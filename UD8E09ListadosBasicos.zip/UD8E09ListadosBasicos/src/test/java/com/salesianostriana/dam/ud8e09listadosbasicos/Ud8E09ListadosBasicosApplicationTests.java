package com.salesianostriana.dam.ud8e09listadosbasicos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ud8E09ListadosBasicosApplicationTests {

	@Test
	void contextLoads() {
	}

}
