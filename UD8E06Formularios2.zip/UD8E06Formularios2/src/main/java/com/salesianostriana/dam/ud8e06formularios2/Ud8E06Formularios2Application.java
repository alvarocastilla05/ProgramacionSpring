package com.salesianostriana.dam.ud8e06formularios2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ud8E06Formularios2Application {

	public static void main(String[] args) {
		SpringApplication.run(Ud8E06Formularios2Application.class, args);
	}

}
