package com.salesianostriana.dam.ud8e06formularios2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ud8E06Formularios2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
