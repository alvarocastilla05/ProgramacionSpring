package com.salesianostriana.dam.ud8e07fechassinbd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ud8E07FechasSinBdApplicationTests {

	@Test
	void contextLoads() {
	}

}
