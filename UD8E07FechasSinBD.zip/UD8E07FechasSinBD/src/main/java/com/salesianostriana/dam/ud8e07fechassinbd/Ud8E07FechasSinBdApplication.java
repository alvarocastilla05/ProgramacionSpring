package com.salesianostriana.dam.ud8e07fechassinbd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ud8E07FechasSinBdApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ud8E07FechasSinBdApplication.class, args);
	}

}
