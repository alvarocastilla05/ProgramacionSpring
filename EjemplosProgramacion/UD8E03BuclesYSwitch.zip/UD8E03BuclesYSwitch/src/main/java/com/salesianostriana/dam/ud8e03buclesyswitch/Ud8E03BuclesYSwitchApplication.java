package com.salesianostriana.dam.ud8e03buclesyswitch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ud8E03BuclesYSwitchApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ud8E03BuclesYSwitchApplication.class, args);
	}

}
