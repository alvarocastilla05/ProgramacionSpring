package com.salesianostriana.dam.ud8e03buclesyswitch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ud8E03BuclesYSwitchApplicationTests {

	@Test
	void contextLoads() {
	}

}
