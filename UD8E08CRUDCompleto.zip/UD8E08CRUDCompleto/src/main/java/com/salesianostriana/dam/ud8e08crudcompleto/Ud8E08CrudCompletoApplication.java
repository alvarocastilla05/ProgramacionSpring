package com.salesianostriana.dam.ud8e08crudcompleto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ud8E08CrudCompletoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ud8E08CrudCompletoApplication.class, args);
	}

}
