package com.salesianostriana.dam.ud8e08crudcompleto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ud8E08CrudCompletoApplicationTests {

	@Test
	void contextLoads() {
	}

}
