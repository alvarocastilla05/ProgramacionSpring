package com.salesianostriana.dam.ud8e02operacionesycondiciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ud8E02OperacionesYCondicionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
