package com.salesianostriana.dam.ud8e02operacionesycondiciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ud8E02OperacionesYCondicionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ud8E02OperacionesYCondicionesApplication.class, args);
	}

}
